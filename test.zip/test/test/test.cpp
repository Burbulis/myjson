// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <cassert>
#include <vector>
#include <string>
#include <functional>
#include <dos.h>
#include <stdio.h>
#include <io.h>
#include <direct.h>
#include <stdlib.h>
#include <boost/asio.hpp>
#include <boost/bind.hpp>




typedef boost::shared_ptr<boost::asio::ip::tcp::socket> socket_ptr;

 struct list_files
 {
	 std::string
	 pwd(void)
	 {
		 char buffer_[MAX_PATH];
		 getcwd(buffer_,MAX_PATH-1);
		 curdir = buffer_;
		 return(curdir);
	 }

	 list_files(std::string pattern)
	 {
		//pwd();
		file_ = _findfirst(pattern.c_str() , &fileinfo);
		if ( fileinfo.attrib != _A_SUBDIR) 
  		   v_s.push_back(fileinfo.name);
		while(_findnext(file_, &fileinfo)==0)
		{
		  if ( fileinfo.attrib != _A_SUBDIR) 
  		    v_s.push_back(std::string(fileinfo.name));
		}
	}

	void to(std::vector<std::string>& out)
	{
	  out = v_s;
	}
 
 private:
	unsigned int file_;
	struct   _finddata_t fileinfo;
	std::vector<std::string> v_s;
    std::string curdir;
 };



 struct session
 {
   session(boost::asio::io_service& io_service):sock_(new boost::asio::ip::tcp::socket(io_service))
   {}

   socket_ptr socket()
   { 
	   return ( sock_ );
   }

  void 
  start()
  {
	  char temp_[]="Hello my dear friend...\n\n";
	  write_(temp_,sizeof(temp_));
	  read_();
  }

  void 
  handle_write(const boost::system::error_code& error)
  {
    if (!error)
    {
		//printf("test!\n\n");
    }
  }

  void write_(char *data , size_t sz)
  {
    boost::asio::async_write(*sock_,
             boost::asio::buffer(data , sz),
             boost::bind(&session::handle_write, this,
             boost::asio::placeholders::error)
		   );
  
  
  }

  void write_(std::string  str)
  {
	  write_(str.c_str() , str.length());
  
  }


  void write_(const char *data , size_t sz)
  {
    char *data_ = new char[sz];
	memset(data_,0,sz);
	memcpy(data_,data,sz);
    boost::asio::async_write(*sock_,
             boost::asio::buffer(data_ , sz),
             boost::bind(&session::handle_write, this,
             boost::asio::placeholders::error)
		   );
  
  
  }

 
 void read_()
 {
	// while (true)
       boost::asio::async_read_until(*sock_, response_, "\r\n",
		    boost::bind(&session::handle_read_status_line, this,
            boost::asio::placeholders::error));
 
 
 }
  
 void 
 handle_read_status_line(const boost::system::error_code& err)
 {
   if (!err)
    {
	 // list_files lf("*.*");
  	  std::istream response_stream(&response_);
      std::string header;
	  while ( std::getline(response_stream, header) )
   	  { 
		printf("header:%s\n",header.c_str());
 
	   /* if (header.find("LS")!=std::string::npos)
	    {
         // printf("\n\n ls - detected \n\n");
		  std::vector<std::string> out_;
		  lf.to( out_ );
		  for (size_t i = 0 ; i< out_.size() ;++i)
		  {
			std::string tmp_ = std::string(out_[i]+std::string("\r\n"));
			write_(tmp_);
		  }
		  //  read_();
		}
	    if (header.find("PWD")!=std::string::npos)
	    {
		   
		   std::string pwd_ = lf.pwd();
		   write_(pwd_.c_str(),pwd_.length());
		 //  read_();	
		}*/

	  }
	  std::vector<char> ss;
	  ss.resize(20000);
	  
	 /// printf("test\n");
	  boost::asio::async_read(*sock_, response_,
          boost::asio::transfer_at_least(1),
		  boost::bind(&session::handle_read_content, this,
            boost::asio::placeholders::error));
	  

	 // getc(stdin);
    }
    else
    {
		printf("Error: %zd \n",err);
    }
 }

 void handle_read_content(const boost::system::error_code& err)
  {
	  std::vector<char> ss;
	  ss.resize(20000);

	  if (!err)
    {
		printf("test!!\n");
       boost::asio::async_read(*sock_, /*response_*/boost::asio::buffer(&ss[0], 20000),
            boost::asio::transfer_at_least(10),
			boost::bind(&session::handle_read_content, this,
            boost::asio::placeholders::error));
    }
    else if (err != boost::asio::error::eof)
    {
       printf("Error: %zd \n",err);
    }
  }


   enum { max_length = 1024 };
   char data_[max_length];
   socket_ptr sock_;
  boost::asio::streambuf response_;

 };

 

 struct server
 {

  server(boost::asio::io_service& io_service, short port) 
		 : io_service_(io_service),acceptor_(io_service, boost::asio::ip::tcp::endpoint
		 (boost::asio::ip::tcp::v4(), port))
 {
	new_session = new session(io_service_);

    acceptor_.async_accept(*new_session->socket(),
        boost::bind(&server::handle_accept, this,new_session->socket(), boost::placeholders::_1));
    
  }

 


 
 void 
 handle_accept(socket_ptr sock, const boost::system::error_code & err)
 {
  //  const size_t MAX_ = 2000;
  //  char buffer_[MAX_];
	boost::system::error_code error;
	new_session->start();

 }
 private:
  boost::asio::io_service& io_service_;
  boost::asio::ip::tcp::acceptor acceptor_;
  session* new_session;
 };

 

int _tmain(int argc, _TCHAR* argv[])
{
//  boost::asio::ip::tcp::endpoint ep( boost::asio::ip::tcp::v4(), 2001); // listen on 2001
//  boost::asio::ip::tcp::acceptor acc(service, ep);
//  socket_ptr sock(new boost::asio::ip::tcp::socket(service));	
	
	boost::asio::io_service service;
	server srv(service,2001);
	
	//  acc.async_accept(*sock,boost::bind( handle_accept, sock, boost::placeholders::_1) );
  service.run();
  return 0;
}

