// test.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <cassert>
#include <vector>
#include <string>
#include <sstream>
#include <functional>
#include <dos.h>
#include <stdio.h>
#include <io.h>
#include <direct.h>
#include <stdlib.h>
#include <iostream>
#include <istream>
#include <ostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/thread/mutex.hpp>

const size_t MAX_BUFFER_SIZE = 8;

typedef boost::shared_ptr<boost::asio::ip::tcp::socket> socket_ptr;

 struct split
 {
	 split(const std::string& str,char splitter):str_(str){
		 for (std::string each; std::getline(str_, each, splitter); particles.push_back(each));
	 }
	 
	 size_t count(void)
	 {
	    return (particles.size());
	 }

	 const std::string& get(size_t index_) const
	 {
		return ( particles[ index_ ] );
	 }
	 
	 ~split(){}
 private:
	 std::vector< std::string > particles;
	 std::istringstream str_;
 
 };


 struct list_files
 {
	 std::string
	 pwd(void)
	 {
		 char buffer_[MAX_PATH];
		 getcwd(buffer_,MAX_PATH-1);
		 curdir = buffer_;
		 return(curdir);
	 }

	 list_files(std::string pattern)
	 {
		file_ = _findfirst(pattern.c_str() , &fileinfo);
		if ( fileinfo.attrib != _A_SUBDIR) 
  		   v_s.push_back(fileinfo.name);
		while(_findnext(file_, &fileinfo)==0)
		{
		  if ( fileinfo.attrib != _A_SUBDIR) 
  		    v_s.push_back(std::string(fileinfo.name));
		}
	}

	void to(std::vector<std::string>& out)
	{
	  out = v_s;
	}
 
 private:
	unsigned int file_;
	struct   _finddata_t fileinfo;
	std::vector<std::string> v_s;
    std::string curdir;

 };



 struct session
 {
  // boost::asio::streambuf response_;
   boost::mutex mutex;
   session(boost::asio::io_service& io_service):sock_(new boost::asio::ip::tcp::socket(io_service))
   {}

   socket_ptr socket()
   { 
	   return ( sock_ );
   }

  void 
  start()
  {
	int x = 5;
	if (std::cref(5).get() == std::cref(x).get())
	  {printf("test! = %d \n\n",x);}
	  char temp_[]="Hello my dear friend...\r\n";
	  write_(temp_,sizeof(temp_));
	  read();
  }

  void 
  handle_write(const boost::system::error_code& error)
  {
    if (!error)
    {
		//printf("test!\n\n");
    }
  }

  void write_(char *data , size_t sz)
  {
    boost::asio::async_write(*sock_,
             boost::asio::buffer(data , sz),
             boost::bind(&session::handle_write, this,
             boost::asio::placeholders::error)
		   );
  
  
  }

  void write_(std::string  str)
  {
	  write_(str.c_str() , str.length());
  
  }


  void write_(const char *data , size_t sz)
  {
    char *data_ = new char[sz];
	memset(data_,0,sz);
	memcpy(data_,data,sz);
    boost::asio::async_write(*sock_,
             boost::asio::buffer(data_ , sz),
             boost::bind(&session::handle_write, this,
             boost::asio::placeholders::error)
		   );
  
  
  }

 
/* void read_()
 {
	  ss.resize(MAX_BUFFER_SIZE);

       boost::asio::async_read(*sock_,boost::asio::buffer(&ss[0], MAX_BUFFER_SIZE),
            boost::asio::transfer_at_least(MAX_BUFFER_SIZE),
			boost::bind(&session::handle_read_content, this,
            boost::asio::placeholders::error));


 }*/
  
 
 void cmd(const split& cmd_)
 {

//	std::vector< char >::iterator it = std::search(result_.begin(),result_.end(),&dirx_[0],&dirx_[4]);
	
	 if (cmd_.get(0).find("dir") != std::string::npos)
	{
		   __asm{nop}
/*		result_.erase(it,it+4);
		std::vector< std::string > out_;
  	
	    list_files lf("*.*");
		lf.to( out_ );
	    
		for (size_t i = 0 ; i < out_.size() ; ++i)
			write_( out_[i]+"\r\n" );*/
 
	}

    if (cmd_.get(0).find("cd") != std::string::npos)
	{

	 //result_.erase(it,it+3);
		   __asm{nop}
		   std::string dir_ = cmd_.get(1);
      int err = chdir( dir_.c_str() );
	  if (!err)
	  {
		printf("change dir..\r\n");
		write_( std::string("change directory..\r\n") );
	  }
	}

    if (cmd_.get(0).find("finish") != std::string::npos)
	{
		write_( std::string("goodbye!..\r\n") );
		exit(0);	
	}	


 }

 /*bool seq_detect()
 {
   return ((std::find(result_.begin(),result_.end(),'\r')!=result_.end()) || (std::find(result_.begin(),result_.end(),'\n')!=result_.end()));
 }

 bool str_seq(std::string& out_)
 {

	 const size_t c_size = result_.size();
	 std::string tmp;
	 bool detect_ = false;


	 for (size_t i = 0 ; i < c_size ;++i)
	 {
         detect_ = ((result_[i] != '\r') && (result_[i] != '\n'));
		 
		 if (detect_)
		 {
			if (result_[i] != 0xB ) 
			{
				tmp.push_back( result_[i] );
			    result_[i] = 0xB ;
			}
			
		 }
	  
		 if (!detect_)
		 { 
			 result_[i] = 0xB;
			 break; 
			__asm{nop}
		 }
     
	 }
	 out_ = tmp;
	 return (!tmp.empty());
 }

 //void clear()
 //{
 //  9i boost::mutex::scoped_lock scoped_lock(mutex);
 //   memset(&ss[0],0,ss.size());
/// }
*/
 void read()
 {
	 boost::asio::async_read_until(*sock_, response_, "\r\n",
		    boost::bind(&session::handle_read_status_line, this,
            boost::asio::placeholders::error));
 
	 
	// boost::asio::async_read_until(* sock_, response_, "\n",  
	//	 boost::bind(&session::handle_read_content, this,
    //      boost::placeholders::_1, boost::placeholders::_2));
 }

  void 
 handle_read_status_line(const boost::system::error_code& err)
 {
	  boost::asio::async_read(*sock_, response_,
          boost::asio::transfer_at_least(1),
		  boost::bind(&session::handle_read_content, this,
            boost::asio::placeholders::error));
  
  }

 void handle_read_content(const boost::system::error_code& err)
  {    
	if (!err)
    {
    // Write all of the data that has been read so far.
		//std::ostringstream str;
		//str << response_.data();
		//std::cout << &response_;
		response_.consume(10);
//		boost::asio::streambuf::const_buffers_type bufs = response_.data();
//		std::string str(boost::asio::buffers_begin(response_), boost::asio::buffers_begin(response_) + response_.data.size());
		const char* header=boost::asio::buffer_cast<const char*>(response_.data());
	    std::string str(header);
		boost::asio::async_read(*sock_, response_,
          boost::asio::transfer_at_least(1),
		  boost::bind(&session::handle_read_content, this,
            boost::asio::placeholders::error));
	}
      // Continue reading remaining data until EOF.
   //   boost::asio::async_read(sock_, response_,
   //       boost::asio::transfer_at_least(1),
	//	  boost::bind(&session::handle_read_content, this,boost::asio::placeholders::error));

  //  boost::asio::async_read(*sock_, response_,
   //         boost::asio::transfer_at_least(10),
//			boost::bind(&session::handle_read_content, this,
  //          boost::asio::placeholders::error));

//	}
 //   else if (err != boost::asio::error::eof)
  //  {
  //     printf("Error: %zd \n",err);
  //  }
//	clear();
 }

//  enum { max_length = 1024 };
//  char data_[max_length];
  socket_ptr sock_;
//  std::vector<char> ss;
//  std::vector<char> result_; 
//  std::vector < std::string > out_str;
  boost::asio::streambuf response_;
};

 

 struct server
 {

  server(boost::asio::io_service& io_service, short port) 
		 : io_service_(io_service),acceptor_(io_service, boost::asio::ip::tcp::endpoint
		 (boost::asio::ip::tcp::v4(), port))
 {
	new_session = new session(io_service_);

    acceptor_.async_accept(*new_session->socket(),
        boost::bind(&server::handle_accept, this,new_session->socket(), boost::placeholders::_1));
    
  }

 


 
 void 
 handle_accept(socket_ptr sock, const boost::system::error_code & err)
 {
  //  const size_t MAX_ = 2000;
  //  char buffer_[MAX_];
	boost::system::error_code error;
	new_session->start();

 }
 private:
  boost::asio::io_service& io_service_;
  boost::asio::ip::tcp::acceptor acceptor_;
  session* new_session;
 };


 

int _tmain(int argc, _TCHAR* argv[])
{
  boost::asio::io_service service;
 // boost::asio::ip::tcp::endpoint ep( boost::asio::ip::tcp::v4(), 2001); // listen on 2001
 // boost::asio::ip::tcp::acceptor acc(service, ep);
  socket_ptr sock(new boost::asio::ip::tcp::socket(service));	
//	printf("test:%s\n",split_.get(0).c_str());
//		printf("test:%s\n",split_.get(1).c_str());

  server srv(service,2001);
	
	//  acc.async_accept(*sock,boost::bind( handle_accept, sock, boost::placeholders::_1) );
  service.run();
  return 0;
}

